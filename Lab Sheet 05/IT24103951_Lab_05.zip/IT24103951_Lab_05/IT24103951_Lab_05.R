setwd("C:\\Users\\damin\\OneDrive\\Desktop\\IT24103951_Lab_05")
getwd()


# 1. 
delivery_data <- read.table("Exercise - Lab 05.txt", header=TRUE, sep="\t")
names(delivery_data) <- c("Delivery_Time")
attach(delivery_data)

# 2.
hist(Delivery_Time, breaks=seq(20, 70, length=10), main="Histogram for Delivery Times", 
     xlab="Delivery Time (minutes)", right=TRUE)

# 3. 
# The distribution appears to be slightly right-skewed with a peak around 38-40 minutes.

# 4. 
freq_table <- table(cut(Delivery_Time, breaks=seq(20, 70, length=10), right=TRUE))
cum_freq <- cumsum(freq_table)
new_points <- c(0, cum_freq)
breaks_upper <- seq(20, 70, length=10)
plot(breaks_upper, new_points, type="l", main="Cumulative Frequency Polygon for Delivery Times", 
     xlab="Delivery Time (minutes)", ylab="Cumulative Frequency")