setwd("C:\\Users\\damin\\OneDrive\\Desktop\\IT24103951_Lab_01")



#01

a <- 5
b <- 3


#02

a + b     
a %/% b    
a %% b     
a / b   
a^b    


#03
#(a)
a > b

#(b)
b == 3 

#(c)
(a > 5) | (b < 2)  


scores <- c(80, 90, 75, 88, 95, NA, 70)

# a)
class(scores)

# b) 
mean(scores, na.rm = TRUE)

# c)
scores[scores > 85]

names <- c("Alice", "Bob", "Charlie", "Diana", "Evan", "Fiona")

pass <- c(TRUE, TRUE, FALSE, TRUE,TRUE, FALSE)
scores <- c(80, 90, 75, 88, 95, 70)

names
pass


results <- data.frame(Name = names, Passed = pass, Score = scores[1:4])
results

names <- c("Alice", "Bob", "Charlie", "Diana", "Evan", "Fiona")
pass <- c(TRUE, TRUE, FALSE, TRUE, TRUE, FALSE)  
scores <- c(80, 90, 75, 88, 95, 70)             

results <- data.frame(Name = names, Passed = pass, Score = scores)
results

str(results)
print(results)





results$Score
max(results$Score, na.rm = TRUE)















