setwd("C:\\Users\\it24103951\\Desktop\\IT24103951_Lab_08")

weights <-read.table("Exercise - LaptopsWeights.txt", header=TRUE)
fix(weights)
attach(weights)  

pop_mean <- mean(Weight.kg.)
pop_sd <- sd(Weight.kg.)

cat("Population Mean:", pop_mean, "\n")
cat("Population Standard Deviation:", pop_sd, "\n")


num_samples <- 25
sample_size <- 6

samples <- matrix(0, nrow = num_samples, ncol = sample_size)
sample_means <- numeric(num_samples)
sample_sds <- numeric(num_samples)

for (i in 1:num_samples) {
  samples[i, ] <- sample(weights, size = sample_size, replace = TRUE)A
  sample_means[i] <- mean(samples[i, ])
  sample_sds[i] <- sd(samples[i, ])
}


cat("\nSample Means and Standard Deviations:\n")
for (i in 1:num_samples) {
  cat("Sample", i, "- Mean:", sample_means[i], "- SD:", sample_sds[i], "\n")
}

mean_of_sample_means <- mean(sample_means)
sd_of_sample_means <- sd(sample_means)

cat("\nMean of Sample Means:", mean_of_sample_means, "\n")
cat("Standard Deviation of Sample Means:", sd_of_sample_means, "\n")

cat("\nRelationship:\n")
cat("The mean of the sample means (", mean_of_sample_means, ") is approximately equal to the population mean (", pop_mean, ").\n")
theoretical_sd <- pop_sd / sqrt(sample_size)
cat("The standard deviation of the sample means (", sd_of_sample_means, ") is approximately equal to the population standard deviation divided by the square root of the sample size (", theoretical_sd, ").\n")



