setwd("C:\\Users\\damin\\OneDrive\\Desktop\\IT24103951_Lab_04")


# Q1
branch_data <- read.csv("Exercise.txt", header = TRUE)

# Q2
str(branch_data)
names(branch_data)
# Branch: Integer, categorical (nominal scale)
# Sales_X1: Numeric, continuous (ratio scale)
# Advertising_X2: Numeric, continuous (ratio scale)
# Years_X3: Numeric, discrete (ratio scale)

# Q3
par(mar = c(4, 4, 2, 2))  # Adjust margins
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales")

# Q4
summary(branch_data$Advertising_X2)
iqr_advertising <- IQR(branch_data$Advertising_X2)
print(paste("IQR of advertising:", iqr_advertising))

# Q5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25, na.rm = TRUE)
  q3 <- quantile(x, 0.75, na.rm = TRUE)
  IQR_val <- q3 - q1
  lower_bound <- q1 - 1.5 * IQR_val
  upper_bound <- q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check outliers in 'years' variable
print("Outliers in 'years' variable:")
print(find_outliers(branch_data$Years))
